print("Andrew Kim")
print("I am a student at Mizzou")
print("I am majoring in Computer Science")
print("I have a pet bird")
